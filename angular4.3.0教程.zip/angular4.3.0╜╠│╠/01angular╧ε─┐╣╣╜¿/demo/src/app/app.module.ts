//导入angular内置模块
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

//导入自定义组件
import { AppComponent } from './app.component';
import { HelloComponent } from './hello/hello.component';

//@NgModule是angular提供的一个对Module进行配置的一个注解。
@NgModule({
	
	//declarations(声明)声明该模块所依赖的Components Service Filter等等.
  declarations: [
    AppComponent,
    HelloComponent
  ],
  
  //imports设置当前模块依赖的其他模块
  imports: [
    BrowserModule
  ],
  
  //设置依赖注入所依赖的服务项
  providers: [],
  
  //设置默认启动的组件
  bootstrap: [AppComponent]
})

//导出当前Module模块
export class AppModule { }
