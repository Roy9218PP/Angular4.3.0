//引入内置模块
import { Component } from '@angular/core';

//为当前组件添加注解。
//@Component 是ng提供的组件类型的注解
@Component({
	//设置当前组件的挂载点
  selector: 'app-root',
  
  //是当前组件的模板文件路径
  templateUrl: './app.component.html',
  
  //是当前组件的样式文件路径
  styleUrls: ['./app.component.css']
})

//导出当前组件
export class AppComponent {
	
	//当前组件的定义的=变量
  title = 'Angular4';
}
