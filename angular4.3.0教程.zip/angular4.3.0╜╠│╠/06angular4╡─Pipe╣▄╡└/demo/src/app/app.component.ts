import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  title = 'angular 4';
  price:number = 0.25
  now:Date = new Date()
  a:number = 2
  n:number = 3
}
