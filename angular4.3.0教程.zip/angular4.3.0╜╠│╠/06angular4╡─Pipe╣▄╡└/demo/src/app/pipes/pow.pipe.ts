import { Pipe, PipeTransform } from '@angular/core';

//@Pipe是管道的注解(装饰器)
@Pipe({
  name: 'pow',
  
  //pure设置是否是纯净管道(Pure Pipe).默认值是true.
  /* pure 管道：仅当管道输入值变化的时候，才执行转换操作，默认的类型是 pure 类型。(备注：输入值变化是指原始数据类型如：string、number、boolean 等的数值或对象的引用值发生变化)

    impure 管道：在每次变化检测期间都会执行，如鼠标点击或移动都会执行 impure 管道
    
    注意在Firefox区分不太理想,可以使用Chrome浏览器
   */
  pure:false
})
export class PowPipe implements PipeTransform {
	
	//transform是当管道被使用时调用的操作,用来定义管道执行的操作,并返回结果
	//参数1:value是管道要操作的原数据
	//参数2:是管道其他配置参数
  transform(value: any, args?: any): any {
  	
  	console.log('======')
  	alert('xxxx')
  	//parseFloat()把某一个数字转化为小数
  	let a = parseFloat(value)
  	
  	//parseInt() 转化为整数,会抹掉小数位
  	
  	//isNaN()判断某一个变量是否不是数字
    return Math.pow(isNaN(a) ? 1 : a,args);
  }

}
