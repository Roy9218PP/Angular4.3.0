import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RouterModule} from '@angular/router'

import {routes} from "./home-router"

import { HomeComponent } from '../home.component';
import { DetailComponent } from '../detail/detail.component';
import { ListComponent } from '../list/list.component';

@NgModule({
  imports: [
    CommonModule,
    //forChild()设置模块的子路由
    RouterModule.forChild(routes)
  ],
  declarations: [
  	HomeComponent, 
  	DetailComponent,
  	ListComponent
  ],
  
  exports:[RouterModule]
})
export class HomeModule { }
