import {Routes} from "@angular/router"

import { HomeComponent } from '../home.component';
import { DetailComponent } from '../detail/detail.component';
import { ListComponent } from '../list/list.component';


export const routes:Routes = [{
	
	path:'',
	component:HomeComponent,
	
	//children配置子路由
	children:[{
		path:'list',
		component:ListComponent
	},{
		path:"detail",
		component:DetailComponent
	}]
}]
