import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import {AppRouterModule} from "./router-module/app-router/app-router.module"

import { AppComponent } from './app.component';
import { HomeComponent } from './components/home/home.component';
import { AboutComponent } from './components/about/about.component';
import { SettingComponent } from './components/setting/setting.component';
import { DetailComponent } from './components/home/detail/detail.component';
import { ListComponent } from './components/home/list/list.component';

@NgModule({
  declarations: [
    AppComponent,
    AboutComponent,
    SettingComponent
   
  ],
  imports: [
    BrowserModule,
    AppRouterModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
