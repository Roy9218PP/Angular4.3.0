import {Routes} from "@angular/router"

import { HomeComponent } from '../../components/home/home.component';
import { AboutComponent } from '../../components/about/about.component';
import { SettingComponent } from '../../components/setting/setting.component';

import { DetailComponent } from '../../components/home/detail/detail.component';
import { ListComponent } from '../../components/home/list/list.component';

import {HomeModule} from '../../components/home/home-router/home.module'

export const routes:Routes = [{
	
	path:'home',
	
	/*
	 * 第一种直接配置子路由
	component:HomeComponent,
	
	//children配置子路由
	children:[{
		path:'list',
		component:ListComponent
	},{
		path:"detail",
		component:DetailComponent
	}]*/
	
	//第二种，加载路由模块
	loadChildren:'../../components/home/home-router/home.module#HomeModule'
},
{
	
	path:'about',
	component:AboutComponent
},
{
	
	path:'setting',
	component:SettingComponent
}]
