export class People {
	
	
	public name:string = 'roy'
	
	eat(){
		
		alert('中午吃啥?')
		
	}
}
