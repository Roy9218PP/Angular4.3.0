import { Component } from '@angular/core';

//引入people类
import {People} from "./classes/people"

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  
  //要想使用依赖注入的方式注入对象,需要在providers内声明依赖项.
  //另外,providers可以放在@Component也可以放在@NgModule内声明.
  //providers:[People]
  
  //providers还有一种更加基础的写法:使用provide和useClass属性来定义依赖项.而这种写法和上边的写法其实一样,都是一种ClassProvider的用法.
  providers:[{
  	provide:People,
  	useClass:People
  }]
})
export class AppComponent {
  title = 'app';
  
  //这种是依靠导入类然后构建类对象,进而访问该类的方法和属性,但是angular提供了一套功能强大的依赖注入机制,可以不用我们手动new一个类对象
  p:People = new People()
  
  
  //angular的依赖注入基本都是把依赖的类对象注入到构造器内,然后就可以直接使用该注入对象,前提是在providers设置了依赖
  constructor(private people:People){
  	
  }
  
  myClick(){
  	
  	this.p.eat()
  	
  	this.people.eat()
  }
}
