import { Component } from '@angular/core';

import {People} from './classes/people'

import {HeroService} from './services/hero.service'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  
  //设置依赖.,这种方式上一节已经讲过,使用的是classProvider,此时无法满足我们的需求,所以可以使用FactoryProvider
  //providers:[People]
  
  //FactoryProvider基本用法
  /*
  providers:[{
  	provide:People,
  	useFactory:()=>{
  		return new People('tom')
  	}
  }]
  */
  
   providers:[
   	HeroService,
  	{
  		provide:People,
  		useFactory:(heroService)=>{
  			return new People('tom', heroService)
  		},
  		//用来设置该服务依赖其他服务
  		deps:[HeroService]
  }]
  
  
})
export class AppComponent {
  title = 'app';
  //private people:People = new People('roy')
  
  //像这样依赖的类的构造器内需要传参的时候,使用ClassProvider已经无法满足需求了.因为依赖注入会帮我们构建一个注入对象,但是无法给构建对象传参.
  constructor(private people:People){
  	
  }
  
  myClick(){
  	
  	this.people.getMyName()
  	
  	let result =  this.people.getHeroNameList()
  	
  	alert(result)
  }
}
