import {HeroService} from '../services/hero.service'

export class People {
	
	constructor(private name:string,private heroService:HeroService){}
	
	getMyName(){
		
		
		alert('我的名字叫'+ this.name)
	}
	
	getHeroNameList(){
		
		return this.heroService.getAllHeros().map((item)=> item.name)
		
	}
}
