import { Injectable } from '@angular/core';

@Injectable()
export class HeroService {

  constructor() { }
	
	getAllHeros(){
		
		return [{id:1,name:"后裔"},{id:2,name:"亚瑟"}]
	}
}
