import { Component ,ReflectiveInjector} from '@angular/core';

import {Car} from './classes/car'
import {Engine} from './classes/engine'


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  
  /*
  providers:[Engine,{
  	provide:Car,
  	useFactory:(engine)=>{
  		
  		return new Car(engine)
  		
  	},
  	deps:[Engine]
  }]
  */
 
 //FactoryProvider可以实现上边的依赖设置,但是使用@Injectable注解会更加方便,只需要在需要设置依赖的类前边添加@Injectable()即可(见car.ts)
 providers:[Car,Engine]
})
export class AppComponent {
  title = 'app';
  
  constructor(private car:Car){
  	
  }
  myClick(){
  	this.car.start()
  	
  	//另外除了上边提到的方式,还可以使用ReflectiveInjector(反射注入器)
  	
  	let injector = ReflectiveInjector.resolveAndCreate([Car,Engine])
  	
  	let car =  injector.get(Car)
  	
  	car.start()
  }
}
