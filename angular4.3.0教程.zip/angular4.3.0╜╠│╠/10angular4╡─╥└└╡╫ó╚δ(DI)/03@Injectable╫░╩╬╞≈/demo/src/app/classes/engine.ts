export class Engine {
	
	constructor(){}
	
	run(){
		
		alert('Fire!!!')
	}
}
