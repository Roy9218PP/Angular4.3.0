import {Routes} from '@angular/router'

import { HomeComponent } from '../home/home.component';
import { SettingComponent } from '../setting/setting.component';
import { AboutComponent } from '../about/about.component';

export const routes:Routes = [

	{
		//angular4的路由配置和angular1不同，对于path不需要加'/'，更不需要加'#'
		path:"home",
		component:HomeComponent
	},
	{
		path:"about",
		component:AboutComponent
	},
	{
		path:"setting",
		component:SettingComponent
	}
]
