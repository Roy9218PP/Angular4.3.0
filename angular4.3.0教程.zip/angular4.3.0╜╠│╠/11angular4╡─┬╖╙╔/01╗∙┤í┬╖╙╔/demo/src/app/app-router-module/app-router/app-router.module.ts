import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
//要使用angular的路由功能需要先引入RouterModule
import {RouterModule} from '@angular/router'

//导入路由配置文件
import {routes} from '../../route-config/routes'


@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],
  declarations: [],
  
  exports:[RouterModule]
})
export class AppRouterModule { }
