import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

//要使用angular的路由功能需要先引入RouterModule
import {RouterModule} from '@angular/router'

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { SettingComponent } from './setting/setting.component';
import { AboutComponent } from './about/about.component';

//导入路由配置文件
import {routes} from './route-config/routes'

//可以直接把路由配置定义为一个模块，然后在当前模块依赖路由模块
import {AppRouterModule} from './app-router-module/app-router/app-router.module'

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    SettingComponent,
    AboutComponent
  ],
  imports: [
    BrowserModule,
    AppRouterModule
    
    //RouterModule提供了两个方法:forRoot设置跟模块(app模块)的路由;forChild设置某一个路由的子路由(嵌套路由)
    //forRoot()的参数是一个路由配置的数组:[{path:"",component:""},{path:"",component:""}...]
    
    //RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
