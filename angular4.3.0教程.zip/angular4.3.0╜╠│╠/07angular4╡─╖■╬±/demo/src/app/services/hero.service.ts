import { Injectable } from '@angular/core';

//@Injectable()注解代表该服务需要通过依赖注入的方式被注入其他类。
@Injectable()
export class HeroService {

	title:string = '' 
	
	heros:Array<{id:number,name:string}> = [
	{id:1,name:"亚瑟"},
	{id:2,name:"老夫子"},
	{id:3,name:"赵云"}
	]
	
	getHeros(){
		
		return this.heros
	}
  constructor() { }

}
