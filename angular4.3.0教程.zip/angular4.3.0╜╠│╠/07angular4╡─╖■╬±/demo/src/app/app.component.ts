import { Component } from '@angular/core';

//引入服务
import {HeroService} from './services/hero.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  
  //需要在providers内设置依赖
  providers:[HeroService]
})
export class AppComponent {
  title = 'app';
  
  heros:Array<{id:number,name:string}>
  
  //把依赖的服务注入到构造器内
  constructor(private heroService:HeroService){
  	
  	this.heros = heroService.getHeros()
  }
}
