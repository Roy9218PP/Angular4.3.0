import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import {FormsModule} from '@angular/forms'

import { AppComponent } from './app.component';

//@NgModule注解。是一个模块的装饰器，用来给给模块声明一些内容
@NgModule({
	
	//declarations(声明).用来声明该模块所依赖的组件等内容
  declarations: [
    AppComponent
  ],
  
  //该模块所依赖的其他模块
  imports: [
    BrowserModule,
    FormsModule
  ],
  
  //该模块的依赖注入项(设置依赖的服务)
  providers: [],
  
  //默认启动的组件
  bootstrap: [AppComponent]
})
export class AppModule { }
