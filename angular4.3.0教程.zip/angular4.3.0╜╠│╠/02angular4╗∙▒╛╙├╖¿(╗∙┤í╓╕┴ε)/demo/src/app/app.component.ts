import { Component } from '@angular/core';

//@Component注解。
@Component({
	//组件的挂载点
  selector: 'app-root',
  
  //组件对应的模板文件路径
  templateUrl: './app.component.html',
  
  //通过拼接的方式定义模板
  //template:``
  
  //组件对应的样式文件路径
  //styleUrls: ['./app.component.css']
  
  //styles通过拼接的方式定义样式
  styles:[`
   	
   	p{
   		color:blue;
   	}
  `]
})

export class AppComponent {
	
	//组件定义的变量放在此处
  title = 'Angular4';
  
  hello:string = 'Hello Angular4'
  
  //private是一个变量修饰符,代表私有变量,只有本类可以访问
  private bindValue:string = '数据绑定'
  
  isClass:boolean = true
  
  private divSize:object = {
  	w:"300",
  	h:"10"
  }
  
  //public是公开的变量,都可以访问
  public bgColor = "orange"
  
  myClick(e){
  	
  	alert('点击了'+ e.target)
  }
  
  keyupEnter(){
  	alert('点击了enter键')
  }
  
  list:Array<string> = ['Angular','Vue','React']
  
  isShow:boolean = false
  
  toggleShow(){
  	
  	this.isShow = !this.isShow
  }
  
  index:number = 2
}
