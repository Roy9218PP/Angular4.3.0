import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

//第一步导入HttpModule，并依赖
import {HttpModule} from "@angular/http"

import { AppComponent } from './app.component';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    HttpModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
