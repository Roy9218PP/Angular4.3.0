import { Component } from '@angular/core';

//导入Http服务
import {Http,Headers,RequestOptions} from "@angular/http"

import 'rxjs'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  
  //注入Http
  constructor(private http:Http){}
  
  getRequest(){
  	//参考:https://www.angular.cn/docs/ts/latest/api/http/index/Http-class.html
  	
  	//创建请求头对象
  	let headers = new Headers()
  	
  	//往请求头追加数据
  	headers.append('X-Roy','xxxxxxxx')
  	
  	
  	this.http.get('/login',{headers}).toPromise().then((res)=>{
  		
  		alert('请求成功')
  		console.log(res)
  	}).catch((err)=>{
  		alert('请求失败')
  	})
  }
  
  postRequest(){
  	
  	//创建请求头对象
  	let headers = new Headers()
  	
  	//往请求头追加数据
  	headers.append('X-Roy','xxxxxxxx') 
  	
  	
  	/*
  	this.http.post(
  		'/register',//url
  		{name:"royyyyyy"},//requestBody
  		{headers}//options
  	)
  	.toPromise()
  	.then((res)=>{
  		 alert('vvvvvv')
  	})
  	.catch((err)=>{
  		alert('xzxxxxxx')
  	})
  	*/
  	
  	let options =  new RequestOptions({headers})
  	this.http.post(
  		'/register',//url
  		{name:"royyyyyy"},//requestBody
  		options //option
  	)
  	.toPromise()
  	.then((res)=>{
  		 alert('vvvvvv')
  	})
  	.catch((err)=>{
  		alert('xzxxxxxx')
  	})
  	
  }
}
