import { DemonewPage } from './app.po';

describe('demonew App', () => {
  let page: DemonewPage;

  beforeEach(() => {
    page = new DemonewPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!');
  });
});
