import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';

//使用CLI的 ng generate 创建的组件会自动被引入当前模块，并且会设置依赖
import { HelloComponent } from './hello/hello.component';
import { TestComponent } from './hello/test/test.component';

@NgModule({
  declarations: [
    AppComponent,
    HelloComponent,
    TestComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
