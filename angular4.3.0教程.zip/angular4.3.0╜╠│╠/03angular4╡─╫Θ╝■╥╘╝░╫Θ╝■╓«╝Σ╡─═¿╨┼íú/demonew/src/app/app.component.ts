import { Component } from '@angular/core';
import { HelloComponent } from './hello/hello.component';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'AppComponnet';
  
  msg:string = "angular4"
  
  receiveEvent(param){
  	alert('wo接收到子组件传的数据了' + param)
  }
  
  receiveOutValue(param){
  	alert('wo接收到子组件传的数据了' + param)
  }
  //constructor(){}
}
