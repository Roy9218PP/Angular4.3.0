import { Component, OnInit, Input ,EventEmitter,Output} from '@angular/core';
//注解Anotation
//依赖注入Dependicy Injection (DI)
@Component({
  selector: 'app-hello',
  templateUrl: './hello.component.html',
  styleUrls: ['./hello.component.css'],
  
  //第一种:使用inputs属性.但是需要在class中定义该变量才能被使用
  inputs:['titleValue'],
  
  //第一种:<1>使用outputs属性,然后借助EventEmitter发射事件来实现子传父.
  outputs:["emitValue"]
})

//导出HelloComponent类,并且该类实现了OnInit接口(interface)
export class HelloComponent implements OnInit {
	
	//使用inputs属性传值需要定义
	private titleValue
	
	//<2>把outputs声明的属性赋值EventEmitter对象.注意要导入EventEmitter
	public emitValue = new EventEmitter()
	
	//<3>使用EventEmitter发射事件
	sendValue(){
		//emit()发射事件
		this.emitValue.emit('this is a test')
	}
	
	//第二种方式,使用@Input注解.但是需要注意要先引入Input
	@Input() msgValue:string
	
	
	//第二种方式,使用@Output注解,实现往外部传值.需要注意引入Output.并且对于EventEmitter需要指定emit()发送的数据类型
	@Output() outValue:EventEmitter<string> = new EventEmitter<string>()
	
	//@Output() outValue:EventEmitter<any> = new EventEmitter<any>()
	
	sendOutValue(){
		this.outValue.emit('test again')
	}
	
	//类的构造器
  constructor() {
  	
  	alert('构造器何时执行?')
  }
	
	//OnInit接口定义的一个方法.它是组件的一个生命周期钩子,当组件被初始化渲染完成时触发的事件
  ngOnInit() {
  	
  	alert('Hello被渲染了')
  }

}
