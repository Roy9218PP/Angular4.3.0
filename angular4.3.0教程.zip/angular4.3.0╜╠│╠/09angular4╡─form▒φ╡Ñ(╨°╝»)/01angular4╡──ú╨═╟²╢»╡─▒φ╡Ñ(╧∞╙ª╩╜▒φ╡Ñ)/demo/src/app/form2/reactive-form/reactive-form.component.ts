import { Component, OnInit } from '@angular/core';
import {NgForm,FormGroup,FormBuilder,FormControl,Validators} from '@angular/forms'
@Component({
  selector: 'app-reactive-form',
  templateUrl: './reactive-form.component.html',
  styleUrls: ['./reactive-form.component.css']
})
export class ReactiveFormComponent implements OnInit {

	//FormBuilder是angular4提供的一个用来构建form表单对象的构造器,通过该构造器可以获取到form中FormGroup表单组对象
  constructor(private builder:FormBuilder) { }

	//初始化username的FormControl对象,设置FormControl绑定的元素的验证规则
	username:FormControl = new FormControl('',[
			Validators.required,
			Validators.minLength(2),
			Validators.maxLength(5)
	])
	

	//通过formBuilder获取formGroup对象,并初始化该表单组中FormControl控制的表单元素
	loginForm:FormGroup = this.builder.group({
		username:this.username
	})
	
	myLogin(){
		
	}
	
  ngOnInit() {
  }

}
