import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
//要使用响应式表单必需引入ReactiveFormsModule
import { ReactiveFormsModule } from '@angular/forms';



import { AppComponent } from './app.component';
import { ReactiveFormComponent } from './form2/reactive-form/reactive-form.component';

@NgModule({
  declarations: [
    AppComponent,
    ReactiveFormComponent
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
