import { Dynamic1Component } from '../dynamic1/dynamic1.component';
import { Dynamic2Component } from '../dynamic2/dynamic2.component';

let conns = [
	Dynamic1Component,
    Dynamic2Component
]

//export default conns 

export  {
	conns
}
