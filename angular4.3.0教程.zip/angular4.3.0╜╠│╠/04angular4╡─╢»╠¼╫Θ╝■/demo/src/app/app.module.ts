import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
/*
import { Dynamic1Component } from './dynamic1/dynamic1.component';
import { Dynamic2Component } from './dynamic2/dynamic2.component';
*/
import { conns } from './dy-components-manager/dy-components-manager';

@NgModule({
  declarations: [
    AppComponent,
    ...conns
  ],
  entryComponents:[
  	...conns
  ],
  
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
