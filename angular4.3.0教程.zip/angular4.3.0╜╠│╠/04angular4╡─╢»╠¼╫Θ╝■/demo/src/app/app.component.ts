import { Component,ViewChild,ViewContainerRef,ComponentFactoryResolver } from '@angular/core';
/*
 * ViewChild：一个属性装饰器(注解)，用来从模板视图中获取对应的元素，可以通过模板变量获取，获取时可以通过 read 属性设置查询的条件，就是说可以把此视图转为不同的实例
 *
 * ViewContainerRef ：一个视图容器，可以在此上面创建、插入、删除组件等等
 * 
 * ComponentFactoryResolver：一个服务，动态加载组件的核心，这个服务可以将一个组件实例呈现到另一个组件视图上
 * 
 * 有了这三个，一个简单的思路便连贯了：特定区域就是一个视图容器，可以通过 ViewChild 来实现获取和查询，然后使用ComponentFactoryResolve将已声明未实例化的组件解析成为可以动态加载的 component，再将此component 呈现到此前的视图容器中
 */

import { Dynamic1Component } from './dynamic1/dynamic1.component';
import { Dynamic2Component } from './dynamic2/dynamic2.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  title = 'Dynamic Component';
  
  isShow:boolean = false
  
  isDynamic1:boolean = true
  
  dyToggle(){
  	
  	this.isShow = !this.isShow
  }
  
  //使用@ViewChild注解来读取一个id为dyroom的元素作为动态组件的挂载点
  @ViewChild('dyroom',{read:ViewContainerRef})
  
  //定义一个ViewContainerRef变量代表视图容器,用来对组件进行增删等操作
  dyViewContainer:ViewContainerRef
  
  constructor(private cfr:ComponentFactoryResolver){}
  
  componentToggle(){
  	
  	this.isDynamic1 = !this.isDynamic1
  	
  	let aComponentClass = this.isDynamic1 ? Dynamic1Component : Dynamic2Component
  	
  	//使用ComponentFactoryResolver创建组件
  	let aComponent = this.cfr.resolveComponentFactory(aComponentClass)
  	
  	//dyViewContainer来把组件渲染到页面
  	this.dyViewContainer.createComponent(aComponent)
  }
}
