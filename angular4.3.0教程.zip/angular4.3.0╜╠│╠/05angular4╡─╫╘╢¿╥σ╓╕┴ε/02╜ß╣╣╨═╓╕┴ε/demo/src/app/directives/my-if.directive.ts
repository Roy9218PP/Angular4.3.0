import { Directive ,Input,TemplateRef,ViewContainerRef} from '@angular/core';

//TemplateRef：是angular提供的访问指令所在的组件模板的API。

@Directive({
  selector: '[appMyIf]'
})
export class MyIfDirective {
	
	//重写set方法接收传进来的值,并且是只能写不能读,根据传入的值来控制该指令所在的元素
	@Input() set appMyIf(condition:boolean){
		
		if(condition){
			
			//显示
			this.viewContainer.createEmbeddedView(this.template)
		}
		else{
			//不显示
			this.viewContainer.clear()
		}
	}
  constructor(private template:TemplateRef<any>,private viewContainer:ViewContainerRef) {
  	
  }

}
