import { FontAndColorDirective } from './font-and-color.directive';

describe('FontAndColorDirective', () => {
  it('should create an instance', () => {
    const directive = new FontAndColorDirective();
    expect(directive).toBeTruthy();
  });
});
