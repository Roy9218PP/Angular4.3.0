import { Directive,ElementRef,Renderer,Input ,HostBinding,OnInit,HostListener,Attribute} from '@angular/core';

//angular4的指令从作用上来分可以分为:
//属性型指令:只对DOM进行样式或是行为的修改等等操作，不会修改DOM结构。
//结构型指令:会对DOM的结构产生影响，导致DOM结构发生变化的指令。比如ngIf、ngFor等。

//angular提供了一系列访问和操作DOM的接口。不主张直接使用原生DOM或是jQuery等操作DOM。比如angular的指令就是一种操作DOM的最好方式。
//ElementRef:是angular提供的一个获取真实DOM元素的API.
//Renderer:是angular提供的对DOM元素进行重新渲染等操作的API。

//@Directive自定义指令的注解
@Directive({
	
	//指令的挂载点,其实是指令的名称
  selector: '[appFontAndColor]'
})
export class FontAndColorDirective implements OnInit{

  //@Input() appFontAndColor:string

  //给appFontAndColor起别名
  @Input('appFontAndColor') color:string
  
  //@HostBinding可以用来绑定指令所在元素(宿主元素),进而获取该元素的属性.此处是重写元素的innerText属性的get方法,并给其设置内容
  @HostBinding() get innerText() {
       
       return `this is a ${this.color} text` ;
  }
 
 //@HostListener注解用来获取指令所在元素,并且给其添加事件监听,相当于AddEvenetListener.然后使用on<Event>()实现事件回调.$event是事件对象
  @HostListener('click',["$event"])
  onClick(e){
  	alert('ooooooo')
  }
 
 //@Attribute注解用来获取宿主元素的某一个属性
  @Attribute("title") title:string
 
  constructor(private ele:ElementRef,private renderer:Renderer) { 
  	
  	//ele.nativeElement 获取原生的DOM元素
  	//renderer.setElementStyle()是用来设置元素样式的
  	
  	
  }

	//指令的生命周期函数--初始化函数
	ngOnInit(){
		
		//参数1:要设置的元素
  		//参数2:要设置的样式属性(驼峰命名法)
  		//参数3:样式的值
 		this.renderer.setElementStyle(this.ele.nativeElement,'fontSize','3rem')
 		
 		
 		this.renderer.setElementStyle(this.ele.nativeElement,'color',this.color ? this.color : "red")
 		
 		
 		//监听指令所在元素被点击有两种方式:
 		//方式一,ElementRef获取元素
 		this.ele.nativeElement.onclick = function(){
 			
 			alert('xxx')
 			alert(this.title)
 		}
 		
 		//方式二,使用@HostListener注解
	}
}
