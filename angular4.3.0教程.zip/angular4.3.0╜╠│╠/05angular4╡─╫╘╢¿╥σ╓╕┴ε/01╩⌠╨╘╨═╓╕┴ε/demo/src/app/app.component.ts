import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  
   //color:string =  "blue"
   
   //重写 color属性的get 方法
   get color(){
   	
   	return "blue"
   }
   
  
}
